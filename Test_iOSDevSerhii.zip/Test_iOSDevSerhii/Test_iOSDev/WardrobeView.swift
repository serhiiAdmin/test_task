import SwiftUI

struct WardrobeView: View {
    @State private var showingAddClothes = false
    @StateObject private var dataManager = DataManager.shared
    
    var body: some View {
        ZStack {
            Color.backgroundDark
                .ignoresSafeArea()
            
            VStack {
                HStack {
                    Text("Wardrobe")
                        .font(.custom("Montserrat-Medium", size: 27.71))
                        .foregroundColor(.white)
                    Spacer()
                }
                .padding(.leading, 15)
                
                if dataManager.clothingItems.isEmpty {
                    VStack {
                        Spacer()
                    }
                } else {
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 20) {
                            ForEach(groupedClothingItems.keys.sorted(), id: \.self) { category in
                                VStack(alignment: .leading, spacing: 12) {
                                    Text(category)
                                        .font(.custom("Montserrat-Medium", size: 19.54))
                                        .foregroundColor(.white)
                                        .padding(.horizontal)
                                    
                                    VStack(spacing: 10) {
                                        ForEach(groupedClothingItems[category] ?? []) { item in
                                            ClothingItemCard(item: item)
                                        }
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        }
                        .padding(.top)
                    }
                }
            }
            .padding()
            .onAppear {
                print("DEBUG: WardrobeView appeared - total items: \(dataManager.clothingItems.count)")
                print("DEBUG: DataManager instance ID: \(ObjectIdentifier(dataManager))")
                for item in dataManager.clothingItems {
                    print("DEBUG: - Item: \(item.title) in category: \(item.category)")
                }
            }

            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: {
                        showingAddClothes = true
                    }) {
                        Image.plusImage
                            .resizable()
                            .frame(width: 22.48, height: 22.47)
                            .background(
                                Circle()
                                    .fill(Color.yellowBar)
                                    .frame(width: 50, height: 50)
                            )
                            .overlay(
                                Circle()
                                    .stroke(Color.white, lineWidth: 1)
                                    .frame(width: 50, height: 50)
                            )
                    }
                    .padding(.trailing, 40)
                    .padding(.bottom, 45)
                }
            }
        }
        .fullScreenCover(isPresented: $showingAddClothes) {
            AddClothesView()
        }
        .onReceive(dataManager.$clothingItems) { items in
            print("DEBUG: WardrobeView received clothingItems update - count: \(items.count)")
        }
    }
    
    private var groupedClothingItems: [String: [ClothingItem]] {
        let grouped = Dictionary(grouping: dataManager.clothingItems) { $0.category }
        print("DEBUG: Grouped items - categories: \(grouped.keys.joined(separator: ", "))")
        for (category, items) in grouped {
            print("DEBUG: Category '\(category)': \(items.count) items")
        }
        return grouped
    }
}


#Preview {
    WardrobeView()
}
