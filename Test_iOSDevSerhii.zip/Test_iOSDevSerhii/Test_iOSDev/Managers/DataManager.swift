import Foundation
import SwiftUI

// Модель для одежды
struct ClothingItem: Codable, Identifiable {
    let id: UUID
    let title: String
    let brand: String
    let color: String
    let level: Int
    let category: String
    let imageData: Data?
    let dateCreated: Date
    
    init(title: String, brand: String, color: String, level: Int, category: String, imageData: Data?) {
        self.id = UUID()
        self.title = title
        self.brand = brand
        self.color = color
        self.level = level
        self.category = category
        self.imageData = imageData
        self.dateCreated = Date()
    }
}

// Модель для наряда
struct Outfit: Codable, Identifiable {
    let id: UUID
    let outwear: Bool
    let bottoms: Bool
    let shoes: Bool
    let selectedOutwearId: UUID?
    let selectedBottomsId: UUID?
    let selectedShoesId: UUID?
    let dateCreated: Date
    
    init(outwear: Bool, bottoms: Bool, shoes: Bool, selectedOutwearId: UUID?, selectedBottomsId: UUID?, selectedShoesId: UUID?) {
        self.id = UUID()
        self.outwear = outwear
        self.bottoms = bottoms
        self.shoes = shoes
        self.selectedOutwearId = selectedOutwearId
        self.selectedBottomsId = selectedBottomsId
        self.selectedShoesId = selectedShoesId
        self.dateCreated = Date()
    }
}

class DataManager: ObservableObject {
    static let shared = DataManager()
    
    @Published var clothingItems: [ClothingItem] = []
    @Published var outfits: [Outfit] = []
    
    private let clothingItemsKey = "clothingItems"
    private let outfitsKey = "outfits"
    
    private init() {
        loadData()
    }
    
    // MARK: - Clothing Items
    func saveClothingItem(_ item: ClothingItem) {
        clothingItems.append(item)
        print("DEBUG: Saved clothing item - title: '\(item.title)', category: '\(item.category)', ID: \(item.id.uuidString)")
        print("DEBUG: Total clothing items now: \(clothingItems.count)")
        saveClothingItems()
    }
    
    func getClothingItems(for category: String) -> [ClothingItem] {
        let filteredItems = clothingItems.filter { $0.category == category }
        print("DEBUG: getClothingItems for category '\(category)' - found \(filteredItems.count) items out of \(clothingItems.count) total")
        for item in filteredItems {
            print("DEBUG: - Item: \(item.title) (ID: \(item.id.uuidString))")
        }
        return filteredItems
    }
    
    func deleteClothingItem(_ item: ClothingItem) {
        clothingItems.removeAll { $0.id == item.id }
        saveClothingItems()
    }
    
    private func saveClothingItems() {
        if let encoded = try? JSONEncoder().encode(clothingItems) {
            UserDefaults.standard.set(encoded, forKey: clothingItemsKey)
        }
    }
    
    // MARK: - Outfits
    func saveOutfit(_ outfit: Outfit) {
        outfits.append(outfit)
        print("DEBUG: Saving outfit - outwear: \(outfit.outwear), bottoms: \(outfit.bottoms), shoes: \(outfit.shoes)")
        print("DEBUG: Selected IDs - outwear: \(outfit.selectedOutwearId?.uuidString ?? "nil"), bottoms: \(outfit.selectedBottomsId?.uuidString ?? "nil"), shoes: \(outfit.selectedShoesId?.uuidString ?? "nil")")
        saveOutfits()
    }
    
    func getLatestOutfit() -> Outfit? {
        print("DEBUG: Total outfits count: \(outfits.count)")
        if let latest = outfits.last {
            print("DEBUG: Latest outfit - outwear: \(latest.outwear), bottoms: \(latest.bottoms), shoes: \(latest.shoes)")
            print("DEBUG: Selected IDs - outwear: \(latest.selectedOutwearId?.uuidString ?? "nil"), bottoms: \(latest.selectedBottomsId?.uuidString ?? "nil"), shoes: \(latest.selectedShoesId?.uuidString ?? "nil")")
        }
        return outfits.last
    }
    
    func getSelectedClothingItem(for category: String) -> ClothingItem? {
        guard let latestOutfit = getLatestOutfit() else { 
            print("DEBUG: No latest outfit found")
            return nil 
        }
        
        let selectedId: UUID?
        switch category {
        case "Outerwear":
            selectedId = latestOutfit.selectedOutwearId
        case "Bottoms":
            selectedId = latestOutfit.selectedBottomsId
        case "Shoes":
            selectedId = latestOutfit.selectedShoesId
        default:
            return nil
        }
        
        guard let selectedId = selectedId else { 
            print("DEBUG: No selected ID for category: \(category)")
            return nil 
        }
        
        let foundItem = clothingItems.first { $0.id == selectedId }
        print("DEBUG: Looking for item with ID: \(selectedId.uuidString) in category: \(category), found: \(foundItem != nil)")
        return foundItem
    }
    
    private func saveOutfits() {
        if let encoded = try? JSONEncoder().encode(outfits) {
            UserDefaults.standard.set(encoded, forKey: outfitsKey)
        }
    }
    
    // MARK: - Data Loading
    private func loadData() {
        print("DEBUG: Starting data loading...")
        
        // Загружаем одежду
        if let clothingData = UserDefaults.standard.data(forKey: clothingItemsKey),
           let decodedClothing = try? JSONDecoder().decode([ClothingItem].self, from: clothingData) {
            clothingItems = decodedClothing
            print("DEBUG: Loaded \(clothingItems.count) clothing items")
        } else {
            print("DEBUG: Failed to load clothing items")
        }
        
        // Загружаем наряды
        if let outfitData = UserDefaults.standard.data(forKey: outfitsKey),
           let decodedOutfits = try? JSONDecoder().decode([Outfit].self, from: outfitData) {
            outfits = decodedOutfits
            print("DEBUG: Loaded \(outfits.count) outfits")
        } else {
            print("DEBUG: Failed to load outfits")
        }
    }
} 