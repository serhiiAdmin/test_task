import Foundation
import CoreLocation
import SwiftUI

// MARK: - Weather Data Models
struct OpenWeatherResponse: Codable {
    let weather: [Weather]
    let main: Main
    let name: String
    let sys: Sys
    let timezone: Int
}

struct Weather: Codable {
    let description: String
}

struct Main: Codable {
    let temp: Double
    let feels_like: Double
    let humidity: Int
}

struct Sys: Codable {
    let country: String
}

// MARK: - APIManager
@MainActor
class APIManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var isLoading = false
    @Published var weatherData: OpenWeatherResponse?
    @Published var errorMessage: String?
    
    private let locationManager = CLLocationManager()
    private let baseURL = "https://api.openweathermap.org/data/2.5"
    private let apiKey = "bd5e378503939ddaee76f12ad7a97608"
    private var locationTimeout: Timer?
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 1000
    }
    
    func requestLocation() {
        print("APIManager: Запрос местоположения")
        isLoading = true
        errorMessage = nil
      
        #if targetEnvironment(simulator)
        print("APIManager: Приложение запущено в симуляторе - геолокация может не работать")
        #endif
        
        // Устанавливаем таймаут на 10 секунд
        locationTimeout = Timer.scheduledTimer(withTimeInterval: 10.0, repeats: false) { [weak self] _ in
            Task { @MainActor in
                await self?.fetchWeatherForDefaultLocation()
            }
        }
        
        let status = locationManager.authorizationStatus
        
        switch status {
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .authorizedWhenInUse, .authorizedAlways:
            locationManager.requestLocation()
        case .denied, .restricted:
            locationTimeout?.invalidate()
            Task {
                await fetchWeatherForDefaultLocation()
            }
        @unknown default:
            locationTimeout?.invalidate()
            errorMessage = "Неизвестная ошибка с геолокацией"
            isLoading = false
        }
    }
    
    // MARK: - CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locationTimeout?.invalidate()
        
        guard let location = locations.first else {
            Task {
                await fetchWeatherForDefaultLocation()
            }
            return
        }

        if location.horizontalAccuracy > 1000 {
            Task {
                await fetchWeatherForDefaultLocation()
            }
            return
        }
        
        Task {
            await fetchWeatherData(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        locationTimeout?.invalidate()
        
        // Определяем тип ошибки
        if let clError = error as? CLError {
            switch clError.code {
            case .denied:
                errorMessage = "Доступ к геолокации запрещен. Разрешите доступ в настройках."
            case .locationUnknown:
                errorMessage = "Местоположение временно недоступно. Проверьте GPS сигнал."
            case .network:
                errorMessage = "Ошибка сети при определении местоположения."
            case .headingFailure:
                errorMessage = "Не удалось определить направление."
            default:
                errorMessage = "Ошибка определения местоположения. Попробуйте выбрать город вручную."
            }
        } else {
            errorMessage = "Ошибка получения местоположения: \(error.localizedDescription)"
        }
        Task {
            await fetchWeatherForDefaultLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            locationManager.requestLocation()
        case .denied, .restricted:
            locationTimeout?.invalidate()
            Task {
                await fetchWeatherForDefaultLocation()
            }
        case .notDetermined:
            break
        @unknown default:
            break
        }
    }
    
    // MARK: - Weather API
    private func fetchWeatherData(latitude: Double, longitude: Double) async {
        do {
            // 1. Формируем URL с координатами
            let urlString = "\(baseURL)/weather?lat=\(latitude)&lon=\(longitude)&appid=\(apiKey)&units=metric"
            
            guard let url = URL(string: urlString) else {
                errorMessage = "Ошибка создания URL"
                isLoading = false
                return
            }

            let (data, response) = try await URLSession.shared.data(from: url)
            
            // Проверяем HTTP статус
            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode != 200 {
                    errorMessage = "Ошибка сервера: \(httpResponse.statusCode)"
                    isLoading = false
                    return
                }
            }

            let weatherData = try JSONDecoder().decode(OpenWeatherResponse.self, from: data)
            
            self.weatherData = weatherData
            self.isLoading = false
            
        } catch {
            errorMessage = "Ошибка получения погоды: \(error.localizedDescription)"
            isLoading = false
        }
    }
    
    // MARK: - Default Location Weather
    func fetchWeatherForDefaultLocation() async {
        do {
            // Используем Киев как город по умолчанию
            let urlString = "\(baseURL)/weather?q=Kyiv&appid=\(apiKey)&units=metric"
            
            guard let url = URL(string: urlString) else {
                errorMessage = "Ошибка создания URL"
                isLoading = false
                return
            }
            let (data, response) = try await URLSession.shared.data(from: url)
            
            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode != 200 {
                    errorMessage = "Ошибка сервера: \(httpResponse.statusCode)"
                    isLoading = false
                    return
                }
            }
            
            let weatherData = try JSONDecoder().decode(OpenWeatherResponse.self, from: data)
            self.weatherData = weatherData
            self.isLoading = false
            
        } catch {
            errorMessage = "Ошибка получения погоды: \(error.localizedDescription)"
            isLoading = false
        }
    }
    
    // MARK: - City Weather
    func fetchWeatherForCity(_ city: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let urlString = "\(baseURL)/weather?q=\(city)&appid=\(apiKey)&units=metric"

            guard let url = URL(string: urlString) else {
                errorMessage = "Ошибка создания URL"
                isLoading = false
                return
            }
            
            let (data, response) = try await URLSession.shared.data(from: url)
            
            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode != 200 {
                    errorMessage = "Ошибка сервера: \(httpResponse.statusCode)"
                    isLoading = false
                    return
                }
            }
            
            let weatherData = try JSONDecoder().decode(OpenWeatherResponse.self, from: data)
            self.weatherData = weatherData
            self.isLoading = false
            
        } catch {
            errorMessage = "Ошибка получения погоды: \(error.localizedDescription)"
            isLoading = false
        }
    }
} 
