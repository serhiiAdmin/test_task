import SwiftUI

struct OutfitItemCard: View {
    let item: ClothingItem
    let category: String
    
    var body: some View {
        VStack(spacing: 8) {
            if let imageData = item.imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 89, height: 89)
                    .clipped()
                   
            } else {
                Image.emptyPhoto
            }
                Text(category)
                    .font(.custom("Montserrat-Light", size: 13.46))
                    .foregroundColor(.white)
                    .lineLimit(1)
            
        }
        .frame(width: 80)
    }
}
