
import SwiftUI

struct ClothingItemsSheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let items: [ClothingItem]
    @Binding var selectedItemId: UUID?
    
    var body: some View {
        ZStack {
            Color.backgroundDark
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                HStack {
                    Text(title.uppercased())
                        .font(.custom("Montserrat-Bold", size: 29.07))
                        .foregroundColor(.white)
                }
                .padding(.horizontal)
                .padding(.top)
                
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(items) { item in
                            HStack {
                                VStack(alignment: .leading, spacing: 7) {
                                    Text(item.title)
                                        .font(.custom("Montserrat-Medium", size: 16.12))
                                        .foregroundColor(.white)
                                    Text(item.brand)
                                        .font(.custom("Montserrat-Light", size: 12.01))
                                        .foregroundColor(.white)
                                }
                                Spacer()
                                
                                RoundedRectangle(cornerRadius: 0)
                                    .fill(getColorFromString(item.color))
                                    .frame(width: 28, height: 29)
                                
                                if selectedItemId == item.id {
                                    Image.checkIm
                                } else {
                                    Image.checkIm.opacity(0)
                                }
                            }
                            .padding(.horizontal, 32)
                            .padding(.vertical, 12)
                            .background(Color.backItemWardrobe)
                            .cornerRadius(8)
                            .padding(.horizontal, 10)
                            .onTapGesture {
                                selectedItemId = item.id
                            }
                        }
                    }
                    .padding(.top)
                }
            }
        }
    }
    
    private func getColorFromString(_ colorString: String) -> Color {
        switch colorString.lowercased() {
        case "black":
            return .black
        case "white":
            return .white
        case "red":
            return .red
        case "blue":
            return .blue
        case "green":
            return .green
        case "yellow":
            return .yellow
        case "purple":
            return .purple
        case "orange":
            return .orange
        default:
            return .gray
        }
    }
}

