import SwiftUI

struct ClothingItemCard: View {
    let item: ClothingItem
    
    var body: some View {
        HStack(spacing: 12) {
            
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title)
                    .font(.custom("Montserrat-Medium", size: 16.12))
                    .foregroundColor(.white)
                    .lineLimit(2)
                
                Text(item.brand)
                    .font(.custom("Montserrat-Light", size: 12.01))
                    .foregroundColor(.white)
                    .lineLimit(1)
            }
            
            Spacer()
            
            Rectangle()
                .fill(colorFromString(item.color))
                .frame(width: 28, height: 29)
               
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 32)
        .background(Color.backItemWardrobe)
        .cornerRadius(8)
    }
    
    private func colorFromString(_ colorString: String) -> Color {
        let lowercased = colorString.lowercased()
        
        switch lowercased {
        case "красный", "red":
            return .red
        case "синий", "blue":
            return .blue
        case "зеленый", "green":
            return .green
        case "желтый", "yellow":
            return .yellow
        case "черный", "black":
            return .black
        case "белый", "white":
            return .white
        case "серый", "gray", "grey":
            return .gray
        case "коричневый", "brown":
            return .brown
        case "оранжевый", "orange":
            return .orange
        case "фиолетовый", "purple":
            return .purple
        case "розовый", "pink":
            return .pink
        case "голубой", "cyan":
            return .cyan
        case "зеленовато-голубой", "teal":
            return .teal
        case "индиго", "indigo":
            return .indigo
        default:
            return .gray
        }
    }
}
