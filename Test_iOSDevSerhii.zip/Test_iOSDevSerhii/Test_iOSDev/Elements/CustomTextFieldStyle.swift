import SwiftUI

struct CustomTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        HStack {
            configuration
                .padding(.leading, 16)
                .foregroundColor(.white)
                .accentColor(.white)
            
            Image.pencilIm
                .padding(.trailing, 16)
        }
        .frame(width: 329, height: 41)
        .background(Color.white.opacity(0.69))
        .cornerRadius(8)
        .foregroundColor(.white)
    }
}
