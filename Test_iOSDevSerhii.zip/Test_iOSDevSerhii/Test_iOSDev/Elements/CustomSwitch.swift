import SwiftUI

struct CustomSwitch: View {
    @Binding var isEnabled: Bool
    
    var body: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.2)) {
                isEnabled.toggle()
            }
        }) {
            ZStack {
                Color.toogleBack
                    .frame(width: 48.79, height: 29.01)
                    .cornerRadius(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(
                                LinearGradient(
                                    gradient: Gradient(colors: [Color.overlayBlack, Color.overlayBlue, Color.overlayBlue, Color.overlayBlue]),
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 2
                            )
                    )
                    .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 2)
                
                Circle()
                    .fill(Color.toogleColor)
                    .frame(width: 22, height: 22)
                    .offset(x: isEnabled ? 10 : -10)
                    .shadow(color: .black.opacity(0.2), radius: 2, x: 0, y: 1)
            }
        }
    }
}

#Preview {
    VStack(spacing: 20) {
        CustomSwitch(isEnabled: .constant(true))
        CustomSwitch(isEnabled: .constant(false))
    }
    .padding()
    .background(Color.black)
} 
