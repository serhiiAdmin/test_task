import SwiftUI

@main
struct Test_iOSDevApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
