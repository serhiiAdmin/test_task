import SwiftUI

extension Color {
    //Background Colors
    static let backgroundDark = Color("backgroundMain")
    static let backgroundCategory = Color("backCategory")
    static let backItemWardrobe = Color("backWardI")
    
    static let yellowBar = Color("yellowTab")
    static let yellowOpacity = Color("outfitBack")
    static let orangeDrop = Color("dropC")
    static let textBlue = Color("blueText")
    static let grayPhoto = Color("grayA")
    static let yellowSave = Color("saveColor")
    static let selectionBack = Color("selection")
    
    //Switch Colors
    static let overlayBlack = Color("BlueBlack")
    static let overlayBlue = Color("blueLight")
    static let toogleColor = Color("blueSwitch")
    static let toogleBack = Color("backToogle")
}
