import SwiftUI

extension Image {
    static let hangImage = Image("hangIcon")
    static let plusImage = Image("plusIm")
    static let downChevron = Image("chevronVector")
    static let pencilIm = Image("pencil")
    static let checkIm = Image("check")
    static let emptyPhoto = Image("empty")
    
    //Slider images
    static let hotImage = Image("palmIm")
    static let cloudImage = Image("cloudIm")
    static let coldImage = Image("snowIm")
    
    static let cameraIm = Image("camera")
    
    static let chevronUp = Image("cheUp")
    static let chevronDown = Image("cheDown")
}
