import SwiftUI

struct StreetView: View {
    @StateObject private var apiManager = APIManager()
    @StateObject private var dataManager = DataManager.shared
    @State private var showingOutfitSelection = false
    
    var currentDate: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        formatter.locale = Locale(identifier: "ua_UA")
        return formatter.string(from: Date())
    }
    
    func getCountryName(from code: String) -> String {
        let countries = [
            "UA": "UKRAINE",
            "US": "USA",
            "GB": "UNITED KINGDOM",
            "DE": "GERMANY",
            "FR": "FRANCE",
            "IT": "ITALY",
            "ES": "SPAIN",
            "PL": "POLAND",
            "CA": "CANADA",
            "AU": "AUSTRALIA",
            "JP": "JAPAN",
            "CN": "CHINA",
            "IN": "INDIA",
            "BR": "BRAZIL",
            "MX": "MEXICO",
            "AR": "ARGENTINA",
            "ZA": "SOUTH AFRICA",
            "EG": "EGYPT",
            "TR": "TURKEY"
        ]
        return countries[code.uppercased()] ?? code.uppercased()
    }
    
    var body: some View {
        ZStack {
            Color.backgroundDark
                .ignoresSafeArea()
            VStack {
                HStack {
                    Text(currentDate)
                        .font(.custom("Montserrat-Medium", size: 24.51))
                        .foregroundColor(.white)
                    
                    Spacer()
                    
                    if apiManager.isLoading {
                        ProgressView()
                            .scaleEffect(0.8)
                            .tint(.white)
                    } else if let weather = apiManager.weatherData {
                        Text("\(Int(weather.main.temp))°")
                            .font(.custom("Montserrat-Light", size: 19.26))
                            .foregroundColor(.white)
                            .fontWeight(.medium)
                    }
                }
                .padding(.top)
                .padding(.leading, 10)
                
                HStack {
                    Spacer()
                    if apiManager.isLoading {
                        ProgressView()
                            .scaleEffect(0.6)
                            .tint(.white)
                    } else if let weather = apiManager.weatherData {
                        Text("\(weather.name.uppercased()), \(getCountryName(from: weather.sys.country))")
                            .font(.custom("Montserrat-Medium", size: 16.34))
                            .foregroundColor(.white)
                    }
                }
                .padding(.top, 1)

                Spacer()

                VStack(spacing: 5) {
                    HStack {
                        Text("Morning")
                            .font(.custom("Montserrat-Light", size: 20.95))
                            .foregroundColor(.white)
                            .padding(.leading, 7)
                        Spacer()
                    }
                    Button(action: {
                        showingOutfitSelection = true
                    }){
                        ZStack {
                            RoundedRectangle(cornerRadius: 7)
                                .fill(Color.yellowOpacity)
                                .frame(width: 358, height: 152)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 7)
                                        .stroke(Color.yellowBar, lineWidth: 1.5)
                                )
                            
                            if let latestOutfit = dataManager.getLatestOutfit(), 
                               (latestOutfit.outwear || latestOutfit.bottoms || latestOutfit.shoes) {
                                // Отображаем выбранные элементы
                                VStack(spacing: 15) {
                                    
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack(spacing: 15) {
                                            if latestOutfit.outwear, let outwearItem = dataManager.getSelectedClothingItem(for: "Outerwear") {
                                                OutfitItemCard(item: outwearItem, category: "Outerwear")
                                            }
                                            
                                            if latestOutfit.bottoms, let bottomsItem = dataManager.getSelectedClothingItem(for: "Bottoms") {
                                                OutfitItemCard(item: bottomsItem, category: "Bottoms")
                                            }
                                            
                                            if latestOutfit.shoes, let shoesItem = dataManager.getSelectedClothingItem(for: "Shoes") {
                                                OutfitItemCard(item: shoesItem, category: "Shoes")
                                            }
                                        }
                                        .padding(.horizontal, 10)
                                       
                                    }
                                    .padding(.horizontal, 15)
                                }
                            } else {
                                VStack(spacing: 10){
                                    Image.hangImage
                                        .resizable()
                                        .frame(width: 109.68, height: 70)
                                    
                                    Text("Pick Outfit")
                                        .font(.custom("Montserrat-Light", size: 20.95))
                                        .foregroundColor(.white.opacity(0.74))
                                }
                                .padding(.top, 10)
                            }
                        }
                    }
                    
                    Spacer()
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Street")
            .navigationBarTitleDisplayMode(.large)
            .onAppear {
                apiManager.requestLocation()
            }
        }
        .fullScreenCover(isPresented: $showingOutfitSelection) {
            OutfitSelectionView()
        }
    }
}
