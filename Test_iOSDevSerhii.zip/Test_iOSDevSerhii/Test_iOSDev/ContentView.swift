import SwiftUI

struct ContentView: View {
    @State private var selectedTab = 0
    
    var body: some View {
        ZStack {
            TabView(selection: $selectedTab) {
                StreetView()
                    .tag(0)
                WardrobeView()
                    .tag(1)
            }

            VStack {
                Spacer()
                
                HStack(spacing: 0) {
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            selectedTab = 0
                        }
                    }) {
                        VStack(spacing: 8) {
                            Text("Street")
                                .font(.custom("Montserrat-Light", size: 25.51))
                                .foregroundColor(selectedTab == 0 ? Color.backgroundDark : Color.backgroundDark.opacity(0.5))
                         
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 86)
                        .background(
                            RoundedRectangle(cornerRadius: 0)
                                .fill(selectedTab == 0 ? Color.yellowBar : Color.clear)
                        )
                    }

                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            selectedTab = 1
                        }
                    }) {
                        VStack(spacing: 8) {
                            Text("Wardrobe")
                                .font(.custom("Montserrat-Light", size: 25.51))
                                .foregroundColor(selectedTab == 1 ? Color.backgroundDark : Color.backgroundDark.opacity(0.5))
                            
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 86)
                        .background(
                            RoundedRectangle(cornerRadius: 0)
                                .fill(selectedTab == 1 ? Color.yellowBar : Color.clear)
                        )
                        
                    }
                }
                .background(Color.white)
                .cornerRadius(23)
                
            }
            .edgesIgnoringSafeArea(.bottom)
        }
    }
}

#Preview {
    ContentView()
}
