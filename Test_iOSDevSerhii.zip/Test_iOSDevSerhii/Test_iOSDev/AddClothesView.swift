import SwiftUI
import PhotosUI

struct AddClothesView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var dataManager = DataManager.shared
    @State private var selectedCategory = "Category"
    @State private var clothingTitle = ""
    @State private var brand = ""
    @State private var selectedColor = "Black"
    @State private var levelValue: Double = 1.0
    @State private var isDropdownExpanded = false
    @State private var selectedImageData: Data?
    @State private var showingImagePicker = false
    @State private var selectedImage: UIImage?
    
    let categories = ["Bottoms", "Outerwear", "Shoes"]
    let colors = [
        ("Black", Color.black),
        ("White", Color.white),
        ("Red", Color.red),
        ("Blue", Color.blue),
        ("Green", Color.green),
        ("Yellow", Color.yellow),
        ("Purple", Color.purple),
        ("Orange", Color.orange)
    ]
    
    var body: some View {
        ZStack {
            Color.backgroundDark
                .ignoresSafeArea()
            
            VStack(spacing: 18) {
                HStack {
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundColor(.white)
                    
                    Spacer()
                }
                .padding(.horizontal)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        
                        VStack(spacing: 0) {
                            if isDropdownExpanded {
                                
                                VStack(spacing: 0) {
                                    Button(action: {
                                        selectedCategory = "Category"
                                        withAnimation(.easeInOut(duration: 0.2)) {
                                            isDropdownExpanded = false
                                        }
                                    }) {
                                        HStack {
                                            Text("Category")
                                                .font(.custom("Montserrat-Medium", size: 16.12))
                                                .foregroundColor(.white)
                                            
                                            Spacer()
                                            ZStack {
                                                RoundedRectangle(cornerRadius: 7)
                                                    .foregroundColor(.white)
                                                    .frame(width: 41.46, height: 33)
                                                Image.downChevron
                                                    .resizable()
                                                    .frame(width: 14.82, height: 11.13)
                                            }
                                            
                                        }
                                        .padding(.leading, 10)
                                        .frame(width: 199.98)
                                        
                                    }
                                    
                                    ForEach(categories, id: \.self) { category in
                                        Button(action: {
                                            selectedCategory = category
                                            withAnimation(.easeInOut(duration: 0.2)) {
                                                isDropdownExpanded = false
                                            }
                                        }) {
                                            HStack {
                                                Text(category)
                                                    .font(.custom("Montserrat-Medium", size: 16.12))
                                                    .foregroundColor(.white)
                                                Spacer()
                                                
                                            }
                                            .padding(5)
                                        }
                                    }
                                }
                                .background(Color.orangeDrop)
                                .cornerRadius(8)
                                .frame(width: 199.98)
                                
                            } else {
                                Button(action: {
                                    withAnimation(.easeInOut(duration: 0.2)) {
                                        isDropdownExpanded.toggle()
                                    }
                                }) {
                                    HStack {
                                        Text(selectedCategory)
                                            .foregroundColor(.white)
                                        
                                        Spacer()
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 7)
                                                .foregroundColor(.white)
                                                .frame(width: 41.46, height: 33)
                                            Image.downChevron
                                                .resizable()
                                                .frame(width: 14.82, height: 11.13)
                                            }
                                            
                                        }
                                        .padding(.leading, 10)
                                        .frame(width: 199.98, height: 33)
                                        .background(Color.orangeDrop)
                                        .cornerRadius(8)
                                    
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Title of clothing")
                            .font(.custom("Montserrat-Medium", size: 15.33))
                            .foregroundColor(Color.textBlue)
                        
                        TextField("Type", text: $clothingTitle)
                            .textFieldStyle(CustomTextFieldStyle())
                            .onChange(of: clothingTitle) { oldValue, newValue in
                                if newValue.count > 25 {
                                    clothingTitle = String(newValue.prefix(25))
                                }
                            }
                        
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Brand")
                            .font(.custom("Montserrat-Medium", size: 15.33))
                            .foregroundColor(Color.textBlue)
                        
                        TextField("Type", text: $brand)
                            .textFieldStyle(CustomTextFieldStyle())
                            .onChange(of: brand) { oldValue, newValue in
                                if newValue.count > 25 {
                                    brand = String(newValue.prefix(25))
                                }
                            }
                    }
                    .padding(.horizontal)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Color")
                            .font(.custom("Montserrat-Medium", size: 15.33))
                            .foregroundColor(Color.textBlue)
                        
                        VStack(spacing: 0) {
                            Button(action: {
                                if let currentIndex = colors.firstIndex(where: { $0.0 == selectedColor }) {
                                    let nextIndex = (currentIndex + 1) % colors.count
                                    selectedColor = colors[nextIndex].0
                                }
                            }) {
                                HStack {
                                    Text(selectedColor)
                                        .foregroundColor(.white)
                                        .padding(.leading, 16)
                                    
                                    Spacer()
                                    
                                    RoundedRectangle(cornerRadius: 4)
                                        .fill(colors.first { $0.0 == selectedColor }?.1 ?? Color.black)
                                        .frame(width: 20, height: 20)
                                        .padding(.trailing, 16)
                                }
                                .frame(width: 329, height: 41)
                                .background(Color.white.opacity(0.69))
                                .cornerRadius(8)
                            }
                        }
                    }
                    .padding(.horizontal)

                    VStack(alignment: .leading, spacing: 15) {
                        Text("Level")
                            .font(.custom("Montserrat-Medium", size: 15.33))
                            .foregroundColor(Color.textBlue)
                        
                        
                        VStack(spacing: 10) {
                            ZStack(alignment: .leading) {
                                Rectangle()
                                    .fill(Color.white)
                                    .frame(width: 329, height: 9)
                                    .cornerRadius(26)

                                Circle()
                                    .fill(Color.textBlue)
                                    .frame(width: 24, height: 24)
                                    .offset(x: CGFloat(levelValue - 1) * 164.5 - 12)
                                    .gesture(
                                        DragGesture()
                                            .onChanged { value in
                                                let position = value.location.x
                                                if position < 110 {
                                                    levelValue = 1
                                                } else if position < 220 {
                                                    levelValue = 2
                                                } else {
                                                    levelValue = 3
                                                }
                                            }
                                    )
                            }
                            .frame(height: 24)
                            
                            HStack {
                                Image.hotImage
                                    .resizable()
                                    .frame(width: 17, height: 17)
                                Spacer()
                                Image.cloudImage
                                    .resizable()
                                    .frame(width: 17, height: 17)
                                Spacer()
                                Image.coldImage
                                    .resizable()
                                    .frame(width: 17, height: 17)
                            }
                            .padding(.horizontal, 15)
                            
                            Text("0 - the level of clothing that is suitablein very hot weather")
                                .font(.custom("Montserrat-Light", size: 12.02))
                                .foregroundColor(.white)
                            Text("4 - the level of clothing that is suitable in very cold weather")
                                .font(.custom("Montserrat-Light", size: 12.02))
                                .foregroundColor(.white)
                            
                            Button(action: {
                                showingImagePicker = true
                            }){
                                ZStack {
                                    RoundedRectangle(cornerRadius: 5)
                                        .frame(width: 321, height: 192)
                                        .foregroundColor(Color.grayPhoto)
                                    
                                    if let selectedImage = selectedImage {
                                        Image(uiImage: selectedImage)
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: 321, height: 192)
                                            .clipped()
                                            .cornerRadius(5)
                                    } else {
                                        Image.cameraIm
                                    }
                                }
                            }
                            .padding(.top, 15)
                            
                            Button(action: {
                                saveClothingItem()
                            }){
                                ZStack {
                                    RoundedRectangle(cornerRadius: 8)
                                        .frame(width: 199.98, height: 33)
                                        .foregroundColor(Color.yellowSave)
                                    
                                    Text("SAVE")
                                        .font(.custom("Montserrat-Medium", size: 21.99))
                                        .foregroundColor(.white)
                                }
                            }
                            .padding(.top, 10)
                        }
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                }
            }
        }
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(selectedImage: $selectedImage, selectedImageData: $selectedImageData)
        }
    }
    
    private func saveClothingItem() {
        guard selectedCategory != "Category" && !clothingTitle.isEmpty else {
          
            return
        }
        
        let clothingItem = ClothingItem(
            title: clothingTitle,
            brand: brand,
            color: selectedColor,
            level: Int(levelValue),
            category: selectedCategory,
            imageData: selectedImageData
        )
        
        dataManager.saveClothingItem(clothingItem)
        dismiss()
    }
}

#Preview {

    AddClothesView()
} 
