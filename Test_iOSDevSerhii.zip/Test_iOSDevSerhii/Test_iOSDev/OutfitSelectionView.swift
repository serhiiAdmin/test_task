import SwiftUI

struct OutfitSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var dataManager = DataManager.shared
    @State private var isOutwearEnabled = false
    @State private var isBottomsEnabled = false
    @State private var isShoesEnabled = false
    @State private var selectedOutwearId: UUID?
    @State private var selectedBottomsId: UUID?
    @State private var selectedShoesId: UUID?
    @State private var showingOutwearSheet = false
    @State private var showingBottomsSheet = false
    @State private var showingShoesSheet = false
    @State private var showingAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        ZStack {
            Color.backgroundDark
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                HStack {
                    Button("Back") {
                        dismiss()
                    }
                    .foregroundColor(.white)
                    
                    Spacer()
                    
                    Button("Save") {
                        saveOutfit()
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
                .padding(.horizontal)
                .padding(.top)
                
                HStack {
                    Text("Outfit Selection")
                        .font(.custom("Montserrat-Medium", size: 27.71))
                        .foregroundColor(.white)
                    Spacer()
                }
                .padding(.leading, 15)

                HStack {
                    Text("Morning")
                        .font(.custom("Montserrat-Light", size: 20.95))
                        .foregroundColor(.white)
                    Spacer()
                }
                .padding(.horizontal)

                VStack(spacing: 0) {
                    HStack {
                        Text("Outwear")
                            .font(.custom("Montserrat-Medium", size: 19.54))
                            .foregroundColor(.white)
                        
                        Spacer()

                        CustomSwitch(isEnabled: $isOutwearEnabled)
                            .onChange(of: isOutwearEnabled) { oldValue, newValue in
                                print("DEBUG: Outwear switch changed from \(oldValue) to \(newValue)")
                                let items = dataManager.getClothingItems(for: "Outerwear")
                                print("DEBUG: Found \(items.count) items for Outerwear category")
                                
                                if newValue && items.isEmpty {
                                    isOutwearEnabled = false
                                    alertMessage = "No outerwear items available. Please add some items first."
                                    showingAlert = true
                                }
                            }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .cornerRadius(isOutwearEnabled ? 0 : 8)

                    if isOutwearEnabled && !dataManager.getClothingItems(for: "Outerwear").isEmpty {
                        let selectedItem = getSelectedItem(for: "Outerwear")
                        HStack {
                            VStack(alignment: .leading, spacing: 7) {
                                Text(selectedItem?.title ?? "Select item")
                                    .font(.custom("Montserrat-Medium", size: 16.12))
                                    .foregroundColor(.white)
                                Text(selectedItem?.brand ?? "")
                                    .font(.custom("Montserrat-Light", size: 12.01))
                                    .foregroundColor(.white)
                            }
                            Spacer()
                            
                            RoundedRectangle(cornerRadius: 0)
                                .fill(getColorFromString(selectedItem?.color ?? ""))
                                .frame(width: 28, height: 29)
                            VStack(spacing: 20) {
                                Image.chevronUp
                                Image.chevronDown
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.backgroundCategory)
                        .padding()
                        .onTapGesture {
                            showingOutwearSheet = true
                        }
                    }
                }
                .background(Color.selectionBack)
                .cornerRadius(8)
                .padding(.horizontal, 10)
                
                VStack(spacing: 0) {
                    HStack {
                        Text("Bottoms")
                            .font(.custom("Montserrat-Medium", size: 19.54))
                            .foregroundColor(.white)
                        
                        Spacer()
                        
                        CustomSwitch(isEnabled: $isBottomsEnabled)
                            .onChange(of: isBottomsEnabled) { oldValue, newValue in
                                let items = dataManager.getClothingItems(for: "Bottoms")
                                print("DEBUG: Bottoms switch changed from \(oldValue) to \(newValue)")
                                print("DEBUG: Found \(items.count) items for Bottoms category")
                                
                                if newValue && items.isEmpty {
                                    isBottomsEnabled = false
                                    alertMessage = "No bottoms items available. Please add some items first."
                                    showingAlert = true
                                }
                            }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .cornerRadius(isBottomsEnabled ? 0 : 8)
                    
                    if isBottomsEnabled && !dataManager.getClothingItems(for: "Bottoms").isEmpty {
                        let selectedItem = getSelectedItem(for: "Bottoms")
                        HStack {
                            VStack(alignment: .leading, spacing: 7) {
                                Text(selectedItem?.title ?? "Select item")
                                    .font(.custom("Montserrat-Medium", size: 16.12))
                                    .foregroundColor(.white)
                                Text(selectedItem?.brand ?? "")
                                    .font(.custom("Montserrat-Light", size: 12.01))
                                    .foregroundColor(.white)
                            }
                            Spacer()
                            
                            RoundedRectangle(cornerRadius: 0)
                                .fill(getColorFromString(selectedItem?.color ?? ""))
                                .frame(width: 28, height: 29)
                            VStack(spacing: 20) {
                                Image.chevronUp
                                Image.chevronDown
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.backgroundCategory)
                        .padding()
                        .onTapGesture {
                            showingBottomsSheet = true
                        }
                    }
                }
                .background(Color.selectionBack)
                .cornerRadius(8)
                .padding(.horizontal, 10)
                
                VStack(spacing: 0) {
                    HStack {
                        Text("Shoes")
                            .font(.custom("Montserrat-Medium", size: 19.54))
                            .foregroundColor(.white)
                        
                        Spacer()
                        
                        CustomSwitch(isEnabled: $isShoesEnabled)
                            .onChange(of: isShoesEnabled) { oldValue, newValue in
                                let items = dataManager.getClothingItems(for: "Shoes")
                                print("DEBUG: Shoes switch changed from \(oldValue) to \(newValue)")
                                print("DEBUG: Found \(items.count) items for Shoes category")
                                
                                if newValue && items.isEmpty {
                                    isShoesEnabled = false
                                    alertMessage = "No shoes items available. Please add some items first."
                                    showingAlert = true
                                }
                            }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .cornerRadius(isShoesEnabled ? 0 : 8)
                    
                    if isShoesEnabled && !dataManager.getClothingItems(for: "Shoes").isEmpty {
                        let selectedItem = getSelectedItem(for: "Shoes")
                        HStack {
                            VStack(alignment: .leading, spacing: 7) {
                                Text(selectedItem?.title ?? "Select item")
                                    .font(.custom("Montserrat-Medium", size: 16.12))
                                    .foregroundColor(.white)
                                Text(selectedItem?.brand ?? "")
                                    .font(.custom("Montserrat-Light", size: 12.01))
                                    .foregroundColor(.white)
                            }
                            Spacer()
                            
                            RoundedRectangle(cornerRadius: 0)
                                .fill(getColorFromString(selectedItem?.color ?? ""))
                                .frame(width: 28, height: 29)
                            VStack(spacing: 20) {
                                Image.chevronUp
                                Image.chevronDown
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.backgroundCategory)
                        .padding()
                        .onTapGesture {
                            showingShoesSheet = true
                        }
                    }
                }
                .background(Color.selectionBack)
                .cornerRadius(8)
                .padding(.horizontal, 10)
                
                Spacer()
            }
        }
        .sheet(isPresented: $showingOutwearSheet) {
            ClothingItemsSheet(
                title: "Outerwear",
                items: dataManager.getClothingItems(for: "Outerwear"),
                selectedItemId: $selectedOutwearId
            )
            .presentationDetents([.height(400)])
            .presentationCornerRadius(20)
        }
        .sheet(isPresented: $showingBottomsSheet) {
            ClothingItemsSheet(
                title: "Bottoms",
                items: dataManager.getClothingItems(for: "Bottoms"),
                selectedItemId: $selectedBottomsId
            )
            .presentationDetents([.height(400)])
            .presentationCornerRadius(20)
        }
        .sheet(isPresented: $showingShoesSheet) {
            ClothingItemsSheet(
                title: "Shoes",
                items: dataManager.getClothingItems(for: "Shoes"),
                selectedItemId: $selectedShoesId
            )
            .presentationDetents([.height(400)])
            .presentationCornerRadius(20)
        }
        .alert("Selection Required", isPresented: $showingAlert) {
            Button("OK") { }
        } message: {
            Text(alertMessage)
        }
        .onAppear {
            print("DEBUG: OutfitSelectionView appeared - total items: \(dataManager.clothingItems.count)")
            print("DEBUG: DataManager instance ID: \(ObjectIdentifier(dataManager))")
            loadCurrentOutfit()
        }
    }
    
    private func getSelectedItem(for category: String) -> ClothingItem? {
        switch category {
        case "Outerwear":
            return dataManager.clothingItems.first { $0.id == selectedOutwearId }
        case "Bottoms":
            return dataManager.clothingItems.first { $0.id == selectedBottomsId }
        case "Shoes":
            return dataManager.clothingItems.first { $0.id == selectedShoesId }
        default:
            return nil
        }
    }
    
    private func loadCurrentOutfit() {
        if let latestOutfit = dataManager.getLatestOutfit() {
            isOutwearEnabled = latestOutfit.outwear
            isBottomsEnabled = latestOutfit.bottoms
            isShoesEnabled = latestOutfit.shoes
            selectedOutwearId = latestOutfit.selectedOutwearId
            selectedBottomsId = latestOutfit.selectedBottomsId
            selectedShoesId = latestOutfit.selectedShoesId
        }
    }
    
    private func saveOutfit() {
        let outfit = Outfit(
            outwear: isOutwearEnabled,
            bottoms: isBottomsEnabled,
            shoes: isShoesEnabled,
            selectedOutwearId: selectedOutwearId,
            selectedBottomsId: selectedBottomsId,
            selectedShoesId: selectedShoesId
        )
        dataManager.saveOutfit(outfit)
    }
    
    private func getColorFromString(_ colorString: String) -> Color {
        switch colorString.lowercased() {
        case "black":
            return .black
        case "white":
            return .white
        case "red":
            return .red
        case "blue":
            return .blue
        case "green":
            return .green
        case "yellow":
            return .yellow
        case "purple":
            return .purple
        case "orange":
            return .orange
        default:
            return .gray
        }
    }
}

